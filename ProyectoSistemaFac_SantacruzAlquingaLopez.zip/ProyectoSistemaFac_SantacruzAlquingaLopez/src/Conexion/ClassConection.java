/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 *
 */
public class ClassConection {
    private static Connection cn;
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String user = "root";
    private static final String password = "";
    private static final String url ="jdbc:mysql://localhost:3306/pfacturacion";
    public Connection conecion(){
        cn = null;
        try{
        Class.forName(driver);
         cn=DriverManager.getConnection(url,user,password);
         }catch(  ClassNotFoundException | SQLException c){}
       return cn; 
    }
    
}
