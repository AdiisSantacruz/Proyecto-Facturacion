
package sistemaventas;


 
public class SistemaDeVentas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         AccessoSistema as =new AccessoSistema();
        as.setLocationRelativeTo(null);
        as.show();
    }
}
